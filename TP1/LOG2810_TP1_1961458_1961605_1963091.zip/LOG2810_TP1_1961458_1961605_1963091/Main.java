public class Main {
    public static void main(String[] args) {
        Graphe graphe = new Graphe("entrepot.txt");
        graphe.interfaceUsager();
        }
    }